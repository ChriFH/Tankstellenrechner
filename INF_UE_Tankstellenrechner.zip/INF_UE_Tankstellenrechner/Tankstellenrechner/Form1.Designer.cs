﻿namespace Tankstellenrechner
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            txt_Benzinpreis = new TextBox();
            txt_Kilo_Tank = new TextBox();
            txt_Kilometer = new TextBox();
            lbl_Benzin = new Label();
            lbl_Kilo_Tank = new Label();
            lbl_Kilometer = new Label();
            txt_Tankmenge = new TextBox();
            lbl_Menge = new Label();
            txt_Tankvolumen = new TextBox();
            lbl_Volumen = new Label();
            lbl_Euro_L = new Label();
            lbl_Km = new Label();
            lbl_Km_Tank = new Label();
            lbl_Liter = new Label();
            lbl_L_Vol = new Label();
            btn_Berechnen = new Button();
            lbl_Distanz = new Label();
            lbl_Verbrauch_L = new Label();
            lbl_Reichweite = new Label();
            lbl_Tankvorgang = new Label();
            lbl_Verbrauch_mpg = new Label();
            tmr_Schleife = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // txt_Benzinpreis
            // 
            txt_Benzinpreis.Location = new Point(317, 120);
            txt_Benzinpreis.Name = "txt_Benzinpreis";
            txt_Benzinpreis.Size = new Size(150, 31);
            txt_Benzinpreis.TabIndex = 0;
            txt_Benzinpreis.Text = "0";
            txt_Benzinpreis.TextAlign = HorizontalAlignment.Center;
            // 
            // txt_Kilo_Tank
            // 
            txt_Kilo_Tank.Location = new Point(317, 177);
            txt_Kilo_Tank.Name = "txt_Kilo_Tank";
            txt_Kilo_Tank.Size = new Size(150, 31);
            txt_Kilo_Tank.TabIndex = 1;
            txt_Kilo_Tank.Text = "0";
            txt_Kilo_Tank.TextAlign = HorizontalAlignment.Center;
            // 
            // txt_Kilometer
            // 
            txt_Kilometer.Location = new Point(317, 239);
            txt_Kilometer.Name = "txt_Kilometer";
            txt_Kilometer.Size = new Size(150, 31);
            txt_Kilometer.TabIndex = 2;
            txt_Kilometer.Text = "0";
            txt_Kilometer.TextAlign = HorizontalAlignment.Center;
            // 
            // lbl_Benzin
            // 
            lbl_Benzin.AutoSize = true;
            lbl_Benzin.Location = new Point(210, 123);
            lbl_Benzin.Name = "lbl_Benzin";
            lbl_Benzin.Size = new Size(101, 25);
            lbl_Benzin.TabIndex = 3;
            lbl_Benzin.Text = "Benzinpreis";
            lbl_Benzin.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbl_Kilo_Tank
            // 
            lbl_Kilo_Tank.AutoSize = true;
            lbl_Kilo_Tank.Location = new Point(20, 180);
            lbl_Kilo_Tank.Name = "lbl_Kilo_Tank";
            lbl_Kilo_Tank.Size = new Size(291, 25);
            lbl_Kilo_Tank.TabIndex = 4;
            lbl_Kilo_Tank.Text = "Kilometerstand letzter Tankvorgang";
            lbl_Kilo_Tank.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbl_Kilometer
            // 
            lbl_Kilometer.AutoSize = true;
            lbl_Kilometer.Location = new Point(180, 242);
            lbl_Kilometer.Name = "lbl_Kilometer";
            lbl_Kilometer.Size = new Size(131, 25);
            lbl_Kilometer.TabIndex = 5;
            lbl_Kilometer.Text = "Kilometerstand";
            lbl_Kilometer.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txt_Tankmenge
            // 
            txt_Tankmenge.Location = new Point(317, 297);
            txt_Tankmenge.Name = "txt_Tankmenge";
            txt_Tankmenge.Size = new Size(150, 31);
            txt_Tankmenge.TabIndex = 6;
            txt_Tankmenge.Text = "0";
            txt_Tankmenge.TextAlign = HorizontalAlignment.Center;
            // 
            // lbl_Menge
            // 
            lbl_Menge.AutoSize = true;
            lbl_Menge.Location = new Point(169, 300);
            lbl_Menge.Name = "lbl_Menge";
            lbl_Menge.Size = new Size(142, 25);
            lbl_Menge.TabIndex = 7;
            lbl_Menge.Text = "Getankte Menge";
            lbl_Menge.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txt_Tankvolumen
            // 
            txt_Tankvolumen.Location = new Point(317, 361);
            txt_Tankvolumen.Name = "txt_Tankvolumen";
            txt_Tankvolumen.Size = new Size(150, 31);
            txt_Tankvolumen.TabIndex = 8;
            txt_Tankvolumen.Text = "0";
            txt_Tankvolumen.TextAlign = HorizontalAlignment.Center;
            // 
            // lbl_Volumen
            // 
            lbl_Volumen.AutoSize = true;
            lbl_Volumen.Location = new Point(195, 364);
            lbl_Volumen.Name = "lbl_Volumen";
            lbl_Volumen.Size = new Size(116, 25);
            lbl_Volumen.TabIndex = 9;
            lbl_Volumen.Text = "Tankvolumen";
            lbl_Volumen.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbl_Euro_L
            // 
            lbl_Euro_L.AutoSize = true;
            lbl_Euro_L.Location = new Point(475, 123);
            lbl_Euro_L.Name = "lbl_Euro_L";
            lbl_Euro_L.Size = new Size(33, 25);
            lbl_Euro_L.TabIndex = 10;
            lbl_Euro_L.Text = "€/l";
            // 
            // lbl_Km
            // 
            lbl_Km.AutoSize = true;
            lbl_Km.Location = new Point(475, 183);
            lbl_Km.Name = "lbl_Km";
            lbl_Km.Size = new Size(37, 25);
            lbl_Km.TabIndex = 11;
            lbl_Km.Text = "km";
            // 
            // lbl_Km_Tank
            // 
            lbl_Km_Tank.AutoSize = true;
            lbl_Km_Tank.Location = new Point(475, 245);
            lbl_Km_Tank.Name = "lbl_Km_Tank";
            lbl_Km_Tank.Size = new Size(37, 25);
            lbl_Km_Tank.TabIndex = 12;
            lbl_Km_Tank.Text = "km";
            // 
            // lbl_Liter
            // 
            lbl_Liter.AutoSize = true;
            lbl_Liter.Location = new Point(475, 303);
            lbl_Liter.Name = "lbl_Liter";
            lbl_Liter.Size = new Size(16, 25);
            lbl_Liter.TabIndex = 13;
            lbl_Liter.Text = "l";
            // 
            // lbl_L_Vol
            // 
            lbl_L_Vol.AutoSize = true;
            lbl_L_Vol.Location = new Point(475, 367);
            lbl_L_Vol.Name = "lbl_L_Vol";
            lbl_L_Vol.Size = new Size(16, 25);
            lbl_L_Vol.TabIndex = 14;
            lbl_L_Vol.Text = "l";
            // 
            // btn_Berechnen
            // 
            btn_Berechnen.Location = new Point(317, 450);
            btn_Berechnen.Name = "btn_Berechnen";
            btn_Berechnen.Size = new Size(150, 47);
            btn_Berechnen.TabIndex = 15;
            btn_Berechnen.Text = "Berechnen";
            btn_Berechnen.UseVisualStyleBackColor = true;
            btn_Berechnen.Click += btn_Berechnen_Click;
            // 
            // lbl_Distanz
            // 
            lbl_Distanz.AutoSize = true;
            lbl_Distanz.Location = new Point(621, 120);
            lbl_Distanz.Name = "lbl_Distanz";
            lbl_Distanz.Size = new Size(187, 25);
            lbl_Distanz.TabIndex = 16;
            lbl_Distanz.Text = "Zurückgelegte Distanz";
            // 
            // lbl_Verbrauch_L
            // 
            lbl_Verbrauch_L.AutoSize = true;
            lbl_Verbrauch_L.Location = new Point(621, 183);
            lbl_Verbrauch_L.Name = "lbl_Verbrauch_L";
            lbl_Verbrauch_L.Size = new Size(268, 25);
            lbl_Verbrauch_L.TabIndex = 17;
            lbl_Verbrauch_L.Text = "Durchschnittsverbrauch l/100km";
            // 
            // lbl_Reichweite
            // 
            lbl_Reichweite.AutoSize = true;
            lbl_Reichweite.Location = new Point(1016, 120);
            lbl_Reichweite.Name = "lbl_Reichweite";
            lbl_Reichweite.Size = new Size(208, 25);
            lbl_Reichweite.TabIndex = 18;
            lbl_Reichweite.Text = "Reichweite (Vollgentankt)";
            // 
            // lbl_Tankvorgang
            // 
            lbl_Tankvorgang.AutoSize = true;
            lbl_Tankvorgang.Location = new Point(1016, 183);
            lbl_Tankvorgang.Name = "lbl_Tankvorgang";
            lbl_Tankvorgang.Size = new Size(207, 25);
            lbl_Tankvorgang.TabIndex = 19;
            lbl_Tankvorgang.Text = "Nächster Tankvorgang in";
            // 
            // lbl_Verbrauch_mpg
            // 
            lbl_Verbrauch_mpg.AutoSize = true;
            lbl_Verbrauch_mpg.Location = new Point(621, 239);
            lbl_Verbrauch_mpg.Name = "lbl_Verbrauch_mpg";
            lbl_Verbrauch_mpg.Size = new Size(240, 25);
            lbl_Verbrauch_mpg.TabIndex = 23;
            lbl_Verbrauch_mpg.Text = "Durchschnittsverbrauch mpg";
            // 
            // tmr_Schleife
            // 
            tmr_Schleife.Tick += tmr_Schleife_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1376, 701);
            Controls.Add(lbl_Verbrauch_mpg);
            Controls.Add(lbl_Tankvorgang);
            Controls.Add(lbl_Reichweite);
            Controls.Add(lbl_Verbrauch_L);
            Controls.Add(lbl_Distanz);
            Controls.Add(btn_Berechnen);
            Controls.Add(lbl_L_Vol);
            Controls.Add(lbl_Liter);
            Controls.Add(lbl_Km_Tank);
            Controls.Add(lbl_Km);
            Controls.Add(lbl_Euro_L);
            Controls.Add(lbl_Volumen);
            Controls.Add(txt_Tankvolumen);
            Controls.Add(lbl_Menge);
            Controls.Add(txt_Tankmenge);
            Controls.Add(lbl_Kilometer);
            Controls.Add(lbl_Kilo_Tank);
            Controls.Add(lbl_Benzin);
            Controls.Add(txt_Kilometer);
            Controls.Add(txt_Kilo_Tank);
            Controls.Add(txt_Benzinpreis);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txt_Benzinpreis;
        private TextBox txt_Kilo_Tank;
        private TextBox txt_Kilometer;
        private Label lbl_Benzin;
        private Label lbl_Kilo_Tank;
        private Label lbl_Kilometer;
        private TextBox txt_Tankmenge;
        private Label lbl_Menge;
        private TextBox txt_Tankvolumen;
        private Label lbl_Volumen;
        private Label lbl_Euro_L;
        private Label lbl_Km;
        private Label lbl_Km_Tank;
        private Label lbl_Liter;
        private Label lbl_L_Vol;
        private Button btn_Berechnen;
        private Label lbl_Distanz;
        private Label lbl_Verbrauch_L;
        private Label lbl_Reichweite;
        private Label lbl_Tankvorgang;
        private Label lbl_Verbrauch_mpg;
        private System.Windows.Forms.Timer tmr_Schleife;
    }
}
