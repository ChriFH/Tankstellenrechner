namespace Tankstellenrechner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Dekleration der Variablen der Textboxeingaben
        double Benzinpreis = 0;
        double Kilo_Tank = 0;
        double Kilometerstand = 0;
        double Tankmenge = 0;
        double Tankvolumen = 0;

        //Dekleration der Variablen der Berechnungsgr��en
        double Distanz = 0;
        double Verbrauch_l = 0;
        double Verbrauch_mpg = 0;
        double Reichweite = 0;
        double Tankvorgang = 0;

        //Deklaration der konstanten Variablen zur mpg Berechnung
        const double mile_km = 1.609347219;
        const double gallon_l = 3.785411784;

        string TankvorgangText = "";
        private void btn_Berechnen_Click(object sender, EventArgs e)
        {
            tmr_Schleife.Enabled = true;        //Timer einschalten

            //Umwandeln der Textboxen Eingaben in Double auf Variablen
            Benzinpreis = Convert.ToDouble(txt_Benzinpreis.Text);
            Kilo_Tank = Convert.ToDouble(txt_Kilo_Tank.Text);
            Kilometerstand = Convert.ToDouble(txt_Kilometer.Text);
            Tankmenge = Convert.ToDouble(txt_Tankmenge.Text);
            Tankvolumen = Convert.ToDouble(txt_Tankvolumen.Text);

            //Berechnung der einelnen Werte
            Distanz = Kilometerstand - Kilo_Tank;
            Verbrauch_l = Tankmenge / Distanz * 100;
            Reichweite = (Tankvolumen / Verbrauch_l) * 100;

            Verbrauch_mpg = (Distanz / mile_km) / Tankmenge * gallon_l ;

            //Schreiben der berechneten Werte auf die Labels
            lbl_Distanz.Text = "Gefahrene Kilometer " + Distanz.ToString("0.##") + " km";
            lbl_Verbrauch_L.Text = "Durchschnittsverbrauch " + Verbrauch_l.ToString("0.##") + " l/100km";
            lbl_Verbrauch_mpg.Text = "Durchschnittsverbrauch " + Verbrauch_mpg.ToString("0.##") + " mpg";
            lbl_Reichweite.Text = "Erwartete Reichweite " + Reichweite.ToString("0.##") + " km";
        }

        private void tmr_Schleife_Tick(object sender, EventArgs e)
        {
            TankvorgangText = "N�chster Tankvorgang in";       //Start Text
            
            //Schleife zur berechnung des n�chsten Tankvorgangs f�r 1 - 15l Reserve im Tank
            for (int Liter = 1; Liter <= 15; Liter++)
            {
                Tankvorgang = ((Tankvolumen - Liter) / Verbrauch_l) * 100;
                TankvorgangText += "\n" + Tankvorgang.ToString("0.##") + " km" + 
                                        " bei " + Liter.ToString() + " Liter Reserve im Tank";
                //Wenn die Schleife im letzten Durchlauf ist 
                if (Liter == 15)
                {
                    tmr_Schleife.Enabled = false;   //Timer stoppen
                }
            }
            
            lbl_Tankvorgang.Text  = TankvorgangText;        //Text auf Label schreiben

        }
    }
}
